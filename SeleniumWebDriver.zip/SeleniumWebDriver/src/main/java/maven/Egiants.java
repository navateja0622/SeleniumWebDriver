package maven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Egiants {

	public static void main(String[] args) {

		Egiants egiants = new Egiants();
		egiants.printSearch();

	}

	private void printSearch() {

		System.setProperty("webdriver.chrome.driver", "/Users/nava/Downloads/chromedriver");

		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.xpath("//*[@id=\"lst-ib\"]")).sendKeys("E-Giants Technologies llc");
		driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[3]/center/input[1]")).submit();

	}

}
